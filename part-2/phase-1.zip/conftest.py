pytest_plugins = [
  "ecommerce.tests.fixtures",
  "ecommerce.tests.selenium",
]