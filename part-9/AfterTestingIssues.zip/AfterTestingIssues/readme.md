# Documentation

## Tutorial Content Overview

---

Docker:

    - [x] Django
    - [x] Redis
    - [x] Celery
    - [x] Celery Beat
    - [x] Flower
    - [x] Visual Studio Code Extension

Database:

    - [x] Validators
    - [x] Field refactoring
    - [x] Add new models

Testing

    - [ ] Unit testing Promotion app
    - [ ] Unit testing Celery

Promotion App Scope: 

    - [ ] Add a new promotion to selectable individual products
    - [ ] Bulk apply discount as a percentage to all chosen products in a promotion
    - [ ] Manually override discount price to allow users to define a custom price
    - [ ] Promotion prices must be auditable over multiple promotions
    - [ ] Specify a timescale (start, end) for the promotion to be active
    - [ ] Promotions can be manually started or stopped
    - [ ] Promotions can be, if flagged, automatically started or stopped based on the promotion timescale
    - [ ] Should allow selection of multiple promotion types (User Defined, Coupons)
    - [ ] A daily automated scheduled task should manage promotion activation (run at 1am every day)

API:

    - [ ] API endpoint refactor to include promotion price
    - [ ] API documentation - Swagger setup


    
